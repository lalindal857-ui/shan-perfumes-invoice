SHAN PERFUMES - Phone-only APK build instructions

මෙය APK එකක් නොව APK එක build කරගැනීමට සූදානම් Android Studio project එකකි.

Computer එකක් නැතිව GitHub Actions හරහා APK එක build කරගන්න:

1. Phone එකේ Chrome browser එකෙන් https://github.com වෙත ගොස් free account එකක් සාදන්න / login වන්න.
2. New repository එකක් සාදන්න. උදා: shan-perfumes-invoice
3. මෙම ZIP එක phone එකට download කර extract කරන්න.
4. Extract කළ project එකේ සියලුම files GitHub repository එකට upload කරන්න. Hidden .github folder එකත් අනිවාර්යයෙන් upload කරන්න.
5. GitHub repository එකේ Actions tab එකට යන්න.
6. "Build SHAN PERFUMES APK" workflow එක තෝරන්න.
7. "Run workflow" ඔබන්න.
8. Build එක සාර්ථක වූ පසු workflow run එක විවෘත කර Artifacts යටතේ SHAN-PERFUMES-debug-APK download කරන්න.
9. ZIP එක extract කර app-debug.apk file එක Android phone එකෙන් install කරන්න.

සටහන්:
- මෙය Android debug APK එකක් build කරයි; Play Store release signing එක ඇතුළත් නොවේ.
- GitHub Actions භාවිතයට GitHub account එකක් සහ internet අවශ්‍යයි.
- App එකේ invoice templates, logo, item rows, totals, local save සහ print-to-PDF අඩංගුය.
- Android 6.0 (API 23) හෝ ඊට ඉහළ Android version එකක් අවශ්‍යය.
